package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {


    String showCal = "" ;
    String num1=" " ;
    String num2 = " ";
    TextView displayCal , result;
    boolean Add, Sub, Multiply, Divide;
    Button button_0, button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8, button_9, button_Add, button_Sub,
            button_Mul, button_Div, button_Equ, button_Del;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_0 = (Button) findViewById(R.id.btn0);
        button_1 = (Button) findViewById(R.id.btn1);
        button_2 = (Button) findViewById(R.id.btn2);
        button_3 = (Button) findViewById(R.id.btn3);
        button_4 = (Button) findViewById(R.id.btn4);
        button_5 = (Button) findViewById(R.id.btn5);
        button_6 = (Button) findViewById(R.id.btn6);
        button_7 = (Button) findViewById(R.id.btn7);
        button_8 = (Button) findViewById(R.id.btn8);
        button_9 = (Button) findViewById(R.id.btn9);
        button_Add = (Button) findViewById(R.id.btn_add);
        button_Sub = (Button) findViewById(R.id.btn_sub);
        button_Mul = (Button) findViewById(R.id.btn_mul);
        button_Div = (Button) findViewById(R.id.btn_div);
        button_Del = (Button) findViewById(R.id.btnAC);
        button_Equ = (Button) findViewById(R.id.btnEQ);

        displayCal = (TextView) findViewById(R.id.textView1);
        result = (TextView) findViewById(R.id.textView2);

        button_1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"1";
                num1+="1";
                displayCal.setText(showCal);
            }
        });

        button_2.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"2";
                num1+="2";
                displayCal.setText(showCal);
            }
        });

        button_3.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"3";
                num1+="3";
                displayCal.setText(showCal);
            }
        });

        button_4.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"4";
                num1+="4";
                displayCal.setText(showCal);
            }
        });

        button_5.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"5";
                num1+="5";
                displayCal.setText(showCal);
            }
        });

        button_6.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"6";
                num1+="6";
                displayCal.setText(showCal);
            }
        });

        button_7.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"7";
                num1+="7";
                displayCal.setText(showCal);
            }
        });

        button_8.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"8";
                num1+="8";
                displayCal.setText(showCal);
            }
        });

        button_9.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"9";
                num1+="9";
                displayCal.setText(showCal);
            }
        });

        button_0.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal= showCal+"0";
                num1+="0";
                displayCal.setText(showCal);
            }
        });
        button_Add.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                showCal+="+";
                num2=num1;
                num1= "";
                Add= true;
                displayCal.setText(showCal);
            }
        });


        button_Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCal+="-";
                num2=num1;
                num1= "";
                Sub= true;
                displayCal.setText(showCal);
            }
        });

        button_Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCal+="x";
                num2=num1;
                num1= "";
                Multiply= true;
                displayCal.setText(showCal);
            }
        });

        button_Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCal+="/";
                num2=num1;
                num1= "";
                Divide= true;
                displayCal.setText(showCal);
            }
        });

        button_Equ.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if (!num1.equals("") & !num2.equals("")){
                    if (Add) {
                        float a1 = Float.parseFloat(num2);
                        float a2 = Float.parseFloat(num1);
                        float sum = a1+a2;
                        result.setText(Float.toString(sum));

                    }

                    if (Sub) {
                        float a1 = Float.parseFloat(num2);
                        float a2 = Float.parseFloat(num1);
                        float sub = a1-a2;
                        result.setText(Float.toString(sub));
                    }

                    if (Multiply) {
                        float a1 = Float.parseFloat(num2);
                        float a2 = Float.parseFloat(num1);
                        float mul = a1*a2;
                        result.setText(Float.toString(mul));
                    }

                    if (Divide) {
                        float a1 = Float.parseFloat(num2);
                        float a2 = Float.parseFloat(num1);
                        float div = a1/a2;
                        result.setText(Float.toString(div));
                    }
                }




            }
        });

        button_Del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               displayCal.setText("");
               result.setText("");
              num1 = num2 = showCal = "";
            }
        });

    }
}
